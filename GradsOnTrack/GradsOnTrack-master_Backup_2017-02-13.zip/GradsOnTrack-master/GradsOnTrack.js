$(document).ready(function()){
	$("glyphicon glyphicon-edit").click(function(){
		$("glyphicons glyphicons-pencil").hide();
	})
}